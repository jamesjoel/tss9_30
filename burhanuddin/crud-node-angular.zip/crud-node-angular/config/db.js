module.exports = {
  dbName: "node_angular",
  employee: "employee"
};
